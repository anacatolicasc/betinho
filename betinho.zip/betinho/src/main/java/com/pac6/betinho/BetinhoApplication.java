package com.pac6.betinho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BetinhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BetinhoApplication.class, args);
	}

}
