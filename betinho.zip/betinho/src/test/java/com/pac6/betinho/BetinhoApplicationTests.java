package com.pac6.betinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
